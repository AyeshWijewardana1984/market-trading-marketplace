import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight, ShoppingCart } from 'lucide-react';
import { PHOTO_PATHS } from '../Images/ProductImageRenderer';
import { HeroFurnitureIllustration } from '../Images/ProductIllustrations';
import { Language } from '../../types/marketplace';

interface HeroSliderProps {
  onShopNow: () => void;
  language?: Language;
}

interface SlideData {
  id: number;
  category: string;
  categorySi: string;
  badge: string;
  badgeSi: string;
  headline: string;
  headlineSi: string;
  highlight: string;
  highlightSi: string;
  description: string;
  descriptionSi: string;
  image: string;
  ctaText: string;
  ctaTextSi: string;
}

export const HeroSlider: React.FC<HeroSliderProps> = ({ onShopNow, language = 'en' }) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [imgErrors, setImgErrors] = useState<{ [key: number]: boolean }>({});
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const slides: SlideData[] = [
    {
      id: 1,
      category: 'Office & Living Collection',
      categorySi: 'කාර්යාල සහ නිවාස එකතුව',
      badge: 'HOT DEAL',
      badgeSi: 'විශේෂ දීමනාව',
      headline: 'Office furniture',
      headlineSi: 'කාර්යාලීය ගෘහ භාණ්ඩ',
      highlight: 'SALE UP TO 50% OFF',
      highlightSi: '50% දක්වා මහා වට්ටම්',
      description: "Architectural beech wood frame with premium high-density velvet cushioning for modern spaces.",
      descriptionSi: 'සුවපහසු ඉරියව්වක් සහතික කරන උසස් තත්ත්වයේ ආකර්ෂණීය විවේක පුටු සහ මේස.',
      image: PHOTO_PATHS.heroSofa,
      ctaText: 'Shop now',
      ctaTextSi: 'දැන් මිලදී ගන්න',
    },
    {
      id: 2,
      category: 'Scandinavian Atelier',
      categorySi: 'නෝර්ඩික් නිර්මාණ එකතුව',
      badge: 'NEW ARRIVALS',
      badgeSi: 'අලුත්ම පැමිණීම්',
      headline: 'Architectural Living',
      headlineSi: 'සුවපහසු ජීවන රටාව',
      highlight: 'SPRING DESIGN 2026',
      highlightSi: 'නවීන වසන්ත සැලසුම් 2026',
      description: 'Handcrafted solid European oak coffee tables, acoustic linen armchairs, and warm diffused lighting.',
      descriptionSi: 'ස්වභාවික දැව රටා කැපී පෙනෙන ශක්තිමත් කෑම මේස, පුටු සහ අලංකාර ලාම්පු එකතුව.',
      image: PHOTO_PATHS.heroLiving,
      ctaText: 'Explore Living',
      ctaTextSi: 'පෙළගැස්ම බලන්න',
    },
    {
      id: 3,
      category: 'Executive Ergonomics',
      categorySi: 'විධායක ආසන සහ මේස',
      badge: 'BEST SELLER',
      badgeSi: 'ඉහළම අලෙවිය',
      headline: 'Smart Workspace',
      headlineSi: 'ස්මාර්ට් වැඩබිම',
      highlight: 'SUMMER CLEARANCE',
      highlightSi: 'ගිම්හාන විශේෂ නිෂ්කාශනය',
      description: 'Precision electric standing desks, active lumbar support seating, and dual-display monitor arms.',
      descriptionSi: 'කාර්යක්ෂමතාව ඉහළ නංවන නවීන විදුලි මේස සහ කොන්දට සුවපහසු ආසන.',
      image: PHOTO_PATHS.heroOffice,
      ctaText: 'Shop Workspace',
      ctaTextSi: 'වැඩබිම සකසන්න',
    },
  ];

  const handleNext = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const handlePrev = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  useEffect(() => {
    if (isPlaying) {
      timerRef.current = setInterval(() => {
        handleNext();
      }, 5500);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, slides.length]);

  return (
    <div
      className="relative rounded-sm overflow-hidden border border-slate-200 shadow-sm group select-none min-h-[340px] sm:min-h-[400px]"
      onMouseEnter={() => setIsPlaying(false)}
      onMouseLeave={() => setIsPlaying(true)}
    >
      {/* Slides Deck */}
      {slides.map((slide, index) => {
        const isActive = index === currentSlide;
        const hasError = imgErrors[slide.id];
        const category = language === 'si' ? slide.categorySi : slide.category;
        const badge = language === 'si' ? slide.badgeSi : slide.badge;
        const headline = language === 'si' ? slide.headlineSi : slide.headline;
        const highlight = language === 'si' ? slide.highlightSi : slide.highlight;
        const description = language === 'si' ? slide.descriptionSi : slide.description;
        const ctaText = language === 'si' ? slide.ctaTextSi : slide.ctaText;

        return (
          <div
            key={slide.id}
            className={`absolute inset-0 transition-opacity duration-700 ease-in-out ${
              isActive ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'
            }`}
          >
            {/* Full-Bleed Background Photo for the entire hero area */}
            <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden">
              {!hasError ? (
                <img
                  src={slide.image}
                  alt={`${slide.headline} - ${slide.highlight}`}
                  referrerPolicy="no-referrer"
                  onError={() => setImgErrors((prev) => ({ ...prev, [slide.id]: true }))}
                  className={`w-full h-full object-cover object-right sm:object-right-bottom transition-transform duration-7000 ease-out ${
                    isActive ? 'scale-105' : 'scale-100'
                  }`}
                />
              ) : (
                <HeroFurnitureIllustration className="w-full h-full object-cover object-right" />
              )}

              {/* White Gradient from Left to Middle for Crisp Text Contrast */}
              <div className="absolute inset-0 bg-gradient-to-r from-white via-white/90 sm:via-white/80 to-transparent to-90% sm:to-65%" />
            </div>

            {/* Slide Text Content & Call-to-Action */}
            <div className="relative z-10 h-full p-6 sm:p-9 lg:p-12 flex flex-col justify-between max-w-sm sm:max-w-md md:max-w-lg">
              <div>
                {/* Category & Tag */}
                <div className="flex items-center gap-2 mb-2">
                  <span className="bg-[#0c1524] text-white text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider font-mono-numbers">
                    {badge}
                  </span>
                  <span className="text-slate-700 text-xs sm:text-sm font-semibold tracking-wide uppercase font-display">
                    {category}
                  </span>
                </div>

                {/* Main Headline & Highlight */}
                <h3 className="text-xl sm:text-2xl font-bold text-slate-800 tracking-tight leading-tight uppercase font-display">
                  {headline}
                </h3>
                <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight leading-tight uppercase mt-0.5 text-[#ea580c] font-display">
                  {highlight}
                </h2>

                {/* Subtitle / Description */}
                <p className="text-slate-600 text-xs sm:text-sm mt-2 sm:mt-3 leading-relaxed font-normal line-clamp-3">
                  {description}
                </p>

                {/* Action Button */}
                <div className="mt-5 sm:mt-6">
                  <button
                    onClick={onShopNow}
                    className="bg-[#ea580c] hover:bg-[#c2410c] text-white px-6 py-2.5 rounded font-bold text-xs uppercase tracking-wider transition-all duration-200 shadow-md cursor-pointer flex items-center gap-2 hover:scale-[1.02] active:scale-95 font-display"
                  >
                    <span>{ctaText}</span>
                    <ShoppingCart className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
      })}

      {/* Navigation Arrow Controls */}
      <button
        onClick={handlePrev}
        className="absolute left-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white/90 hover:bg-white text-slate-800 flex items-center justify-center shadow-lg border border-slate-200/80 transition-all cursor-pointer z-20 hover:scale-105 active:scale-95"
        title="Previous Slide"
      >
        <ChevronLeft className="w-5 h-5 text-slate-700" />
      </button>

      <button
        onClick={handleNext}
        className="absolute right-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white/90 hover:bg-white text-slate-800 flex items-center justify-center shadow-lg border border-slate-200/80 transition-all cursor-pointer z-20 hover:scale-105 active:scale-95"
        title="Next Slide"
      >
        <ChevronRight className="w-5 h-5 text-slate-700" />
      </button>

      {/* Bottom Controls Bar: Slide Indicators */}
      <div className="absolute bottom-3.5 left-6 sm:left-12 flex items-center gap-2 z-20">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => goToSlide(index)}
            className={`h-2 rounded-full transition-all cursor-pointer ${
              index === currentSlide ? 'w-6 bg-[#ea580c]' : 'w-2 bg-slate-300 hover:bg-slate-400'
            }`}
            title={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </div>
  );
};
