import React, { useState } from 'react';
import {
  Wrench,
  Sparkles,
  Gift,
  Shirt,
  Briefcase,
  FlaskConical,
  Eye,
  Home,
  Radio,
  Gem,
  MoreHorizontal,
  ChevronRight,
} from 'lucide-react';
import { CATEGORIES } from '../../data/products';
import { Language } from '../../types/marketplace';

interface CategorySidebarProps {
  isOpen: boolean;
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
  language?: Language;
}

export const CategorySidebar: React.FC<CategorySidebarProps> = ({
  isOpen,
  selectedCategory,
  onSelectCategory,
  language = 'en',
}) => {
  const [hoveredCategory, setHoveredCategory] = useState<string | null>(null);

  if (!isOpen) return null;

  const getIcon = (name: string) => {
    switch (name) {
      case 'Wrench':
        return <Wrench className="w-4 h-4 text-slate-400 group-hover:text-[#ea580c] transition-colors" />;
      case 'Sparkles':
        return <Sparkles className="w-4 h-4 text-slate-400 group-hover:text-[#ea580c] transition-colors" />;
      case 'Gift':
        return <Gift className="w-4 h-4 text-slate-400 group-hover:text-[#ea580c] transition-colors" />;
      case 'Shirt':
        return <Shirt className="w-4 h-4 text-slate-400 group-hover:text-[#ea580c] transition-colors" />;
      case 'Briefcase':
        return <Briefcase className="w-4 h-4 text-slate-400 group-hover:text-[#ea580c] transition-colors" />;
      case 'FlaskConical':
        return <FlaskConical className="w-4 h-4 text-slate-400 group-hover:text-[#ea580c] transition-colors" />;
      case 'Eye':
        return <Eye className="w-4 h-4 text-slate-400 group-hover:text-[#ea580c] transition-colors" />;
      case 'Home':
        return <Home className="w-4 h-4 text-slate-400 group-hover:text-[#ea580c] transition-colors" />;
      case 'Radio':
        return <Radio className="w-4 h-4 text-slate-400 group-hover:text-[#ea580c] transition-colors" />;
      case 'Gem':
        return <Gem className="w-4 h-4 text-slate-400 group-hover:text-[#ea580c] transition-colors" />;
      default:
        return <MoreHorizontal className="w-4 h-4 text-slate-400 group-hover:text-[#ea580c] transition-colors" />;
    }
  };

  return (
    <div className="bg-white border border-slate-200 border-t-0 shadow-sm relative z-30">
      <ul className="divide-y divide-slate-100 text-xs text-slate-700 font-medium">
        {CATEGORIES.map((cat) => {
          const catName = language === 'si' && cat.nameSi ? cat.nameSi : cat.name;
          const isSelected = selectedCategory === cat.name || selectedCategory === cat.nameSi;
          const isHovered = hoveredCategory === cat.id;
          const subcategories = language === 'si' && cat.subcategoriesSi ? cat.subcategoriesSi : cat.subcategories;

          return (
            <li
              key={cat.id}
              className="relative group"
              onMouseEnter={() => setHoveredCategory(cat.id)}
              onMouseLeave={() => setHoveredCategory(null)}
            >
              <button
                onClick={() => onSelectCategory(cat.name)}
                className={`w-full px-3.5 py-2.5 flex items-center justify-between text-left transition-colors cursor-pointer group-hover:bg-slate-50 group-hover:text-[#ea580c] ${
                  isSelected ? 'bg-orange-50/70 text-[#ea580c] font-semibold border-l-3 border-[#ea580c]' : 'border-l-3 border-transparent'
                }`}
              >
                <div className="flex items-center gap-2.5 truncate">
                  {getIcon(cat.iconName)}
                  <span className="truncate">{catName}</span>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-[#ea580c] shrink-0 transition-colors" />
              </button>

              {/* Flyout Submenu on Hover */}
              {isHovered && (
                <div className="absolute left-full top-0 ml-[-1px] w-60 bg-white border border-slate-200 shadow-xl rounded-r py-2 z-50 animate-in fade-in duration-100">
                  <div className="px-3 py-1 font-bold border-b border-slate-100 text-[11px] uppercase tracking-wider text-[#ea580c] font-display">
                    {catName}
                  </div>
                  <div className="py-1">
                    {subcategories.map((sub, idx) => (
                      <button
                        key={idx}
                        onClick={() => onSelectCategory(cat.subcategories[idx] || sub)}
                        className="w-full text-left px-3 py-1.5 hover:bg-orange-50 hover:text-[#ea580c] text-slate-600 transition-colors text-xs cursor-pointer truncate"
                      >
                        {sub}
                      </button>
                    ))}
                  </div>
                  <div className="px-3 pt-2 pb-1 border-t border-slate-100 text-[10px] text-slate-400 flex justify-between font-mono-numbers">
                    <span>{language === 'si' ? 'සත්‍යාපිත සැපයුම්කරුවන්' : 'Verified Suppliers'}</span>
                    <span className="font-semibold text-slate-700">{cat.itemCount}+</span>
                  </div>
                </div>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
};
