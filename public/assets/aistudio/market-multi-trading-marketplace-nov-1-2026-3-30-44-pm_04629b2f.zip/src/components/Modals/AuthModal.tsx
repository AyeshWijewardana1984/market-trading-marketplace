import React, { useState } from 'react';
import { X, Lock, Mail, Store } from 'lucide-react';
import { Language } from '../../types/marketplace';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'login' | 'register';
  onSuccess: (email: string) => void;
  language?: Language;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  initialMode = 'login',
  onSuccess,
  language = 'si',
}) => {
  const [mode, setMode] = useState<'login' | 'register'>(initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isVendor, setIsVendor] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      onSuccess(email);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4">
      <div onClick={onClose} className="fixed inset-0 bg-black/60 backdrop-blur-xs" />

      <div className="relative bg-white rounded-md shadow-2xl max-w-md w-full overflow-hidden z-10 animate-in fade-in zoom-in-95 duration-150 p-6">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-800 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Tabs */}
        <div className="flex border-b border-slate-200 mb-6 font-display">
          <button
            onClick={() => setMode('login')}
            className={`pb-3 text-sm font-bold flex-1 text-center cursor-pointer ${
              mode === 'login'
                ? 'text-[#ea580c] border-b-2 border-[#ea580c]'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            {language === 'si' ? 'ඇතුල් වන්න' : 'Sign In'}
          </button>
          <button
            onClick={() => setMode('register')}
            className={`pb-3 text-sm font-bold flex-1 text-center cursor-pointer ${
              mode === 'register'
                ? 'text-[#ea580c] border-b-2 border-[#ea580c]'
                : 'text-slate-500 hover:text-slate-800'
            }`}
          >
            {language === 'si' ? 'ගිණුමක් සාදන්න' : 'Register Account'}
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1 font-sans">
              {language === 'si' ? 'ඊමේල් ලිපිනය' : 'Email Address'}
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={language === 'si' ? 'ඔබගේ ඊමේල් ලිපිනය' : 'you@example.com'}
                className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded text-xs focus:outline-none focus:border-[#ea580c]"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1 font-sans">
              {language === 'si' ? 'මුරපදය' : 'Password'}
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded text-xs focus:outline-none focus:border-[#ea580c]"
              />
            </div>
          </div>

          {mode === 'register' && (
            <div className="flex items-center gap-2 p-2.5 bg-orange-50 border border-orange-200 rounded">
              <input
                type="checkbox"
                id="vendorCheck"
                checked={isVendor}
                onChange={(e) => setIsVendor(e.target.checked)}
                className="accent-[#ea580c]"
              />
              <label htmlFor="vendorCheck" className="text-xs font-semibold text-slate-800 flex items-center gap-1.5 cursor-pointer font-sans">
                <Store className="w-3.5 h-3.5 text-[#ea580c]" />
                <span>{language === 'si' ? 'බහු-විකුණුම්කාර වෙළෙන්දෙකු ලෙස ලියාපදිංචි වන්න' : 'Apply as a Multi-Vendor Seller'}</span>
              </label>
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-[#ea580c] hover:bg-[#c2410c] text-white py-2.5 rounded text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer font-display"
          >
            {mode === 'login'
              ? (language === 'si' ? 'Market ගිණුමට ඇතුල් වන්න' : 'Sign In to Market')
              : (language === 'si' ? 'වෙළඳපොළ ගිණුම සාදන්න' : 'Create Marketplace Account')}
          </button>
        </form>

        <div className="mt-4 text-center text-[11px] text-slate-400 font-sans">
          {language === 'si'
            ? 'නිරූපණ ඇතුල්වීම: සියලු ගැනුම්කරු/විකුණුම්කරු විශේෂාංග අත්විඳීමට ඕනෑම ඊමේල් ලිපිනයක් ඇතුළත් කරන්න.'
            : 'Demo login: Enter any email to experience full multi-vendor buyer/seller features.'}
        </div>
      </div>
    </div>
  );
};
