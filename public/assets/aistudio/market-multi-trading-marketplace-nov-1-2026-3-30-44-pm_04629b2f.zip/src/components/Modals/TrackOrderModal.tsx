import React, { useState } from 'react';
import { X, Truck, Package, CheckCircle2, MapPin, Search } from 'lucide-react';
import { Language } from '../../types/marketplace';

interface TrackOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  language?: Language;
}

export const TrackOrderModal: React.FC<TrackOrderModalProps> = ({ isOpen, onClose, language = 'si' }) => {
  const [orderNumber, setOrderNumber] = useState('MKT-2026-8941');
  const [tracked, setTracked] = useState(true);

  if (!isOpen) return null;

  const handleTrack = (e: React.FormEvent) => {
    e.preventDefault();
    if (orderNumber.trim()) {
      setTracked(true);
    }
  };

  const steps = [
    {
      label: language === 'si' ? 'ඇණවුම තහවුරු විය' : 'Order Confirmed',
      date: language === 'si' ? 'ඔක් 28, පෙ.ව. 09:30' : 'Oct 28, 09:30 AM',
      completed: true,
      icon: CheckCircle2
    },
    {
      label: language === 'si' ? 'ඇසුරුම් කර පිටත් කරන ලදී' : 'Packed & Dispatched',
      date: language === 'si' ? 'ඔක් 29, ප.ව. 02:15' : 'Oct 29, 02:15 PM',
      completed: true,
      icon: Package
    },
    {
      label: language === 'si' ? 'ප්‍රවාහනයේ පවතී (කලාපීය මධ්‍යස්ථානය)' : 'In Transit (Regional Hub)',
      date: language === 'si' ? 'ඔක් 30, ප.ව. 08:45' : 'Oct 30, 08:45 PM',
      completed: true,
      icon: Truck,
      active: true
    },
    {
      label: language === 'si' ? 'බෙදාහැරීමට පිටත්ව ඇත' : 'Out for Delivery',
      date: language === 'si' ? 'නොවැ 01 බලාපොරොත්තු වේ' : 'Expected Nov 01',
      completed: false,
      icon: MapPin
    },
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4">
      <div onClick={onClose} className="fixed inset-0 bg-black/60 backdrop-blur-xs" />

      <div className="relative bg-white rounded-md shadow-2xl max-w-lg w-full overflow-hidden z-10 animate-in fade-in zoom-in-95 duration-150 p-6">
        <div className="flex items-center justify-between pb-3 border-b border-slate-200">
          <div className="flex items-center gap-2">
            <Truck className="w-5 h-5 text-[#ea580c]" />
            <h3 className="font-bold text-sm uppercase tracking-wider text-slate-900 font-display">
              {language === 'si' ? 'පාර්සලය ලුහුබැඳීම' : 'Track Shipment Order'}
            </h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-800 cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Input Form */}
        <form onSubmit={handleTrack} className="mt-4 flex gap-2">
          <input
            type="text"
            value={orderNumber}
            onChange={(e) => setOrderNumber(e.target.value)}
            placeholder={language === 'si' ? 'ඇණවුම් අංකය ඇතුළත් කරන්න (උදා: MKT-2026-8941)' : 'Enter Order ID (e.g. MKT-2026-8941)'}
            className="flex-1 px-3 py-2 border border-slate-300 rounded text-xs focus:outline-none focus:border-[#ea580c] font-mono-numbers uppercase"
          />
          <button
            type="submit"
            className="px-4 py-2 bg-[#ea580c] hover:bg-[#c2410c] text-white rounded text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 cursor-pointer font-display"
          >
            <Search className="w-3.5 h-3.5" />
            <span>{language === 'si' ? 'සොයන්න' : 'Track'}</span>
          </button>
        </form>

        {tracked && (
          <div className="mt-6 bg-slate-50 border border-slate-200 rounded p-4 font-sans">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 text-xs">
              <div>
                <span className="text-slate-500">{language === 'si' ? 'ඇණවුම් අංකය: ' : 'Order ID: '}</span>
                <span className="font-mono-numbers font-bold text-slate-800">{orderNumber}</span>
              </div>
              <span className="bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded text-[10px] font-display">
                {language === 'si' ? 'නියමිත වේලාවට' : 'ON SCHEDULE'}
              </span>
            </div>

            <div className="py-3 text-xs text-slate-600">
              <p>{language === 'si' ? 'ප්‍රවාහකයා: ' : 'Carrier: '}<strong>Global Express Logistics</strong></p>
              <p className="mt-1">{language === 'si' ? 'ගමනාන්තය: ' : 'Destination: '}<strong>{language === 'si' ? 'කොළඹ, ශ්‍රී ලංකාව' : 'San Francisco, CA, USA'}</strong></p>
            </div>

            {/* Timeline */}
            <div className="mt-4 space-y-4 relative before:absolute before:left-3 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
              {steps.map((s, idx) => {
                const Icon = s.icon;
                return (
                  <div key={idx} className="flex items-start gap-3 relative z-10">
                    <div
                      className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 text-white ${
                        s.active
                          ? 'bg-[#ea580c] ring-4 ring-orange-100'
                          : s.completed
                          ? 'bg-emerald-500'
                          : 'bg-slate-300'
                      }`}
                    >
                      <Icon className="w-3 h-3" />
                    </div>
                    <div className="flex-1">
                      <div className="text-xs font-bold text-slate-800 flex items-center justify-between font-display">
                        <span>{s.label}</span>
                        {s.active && (
                          <span className="text-[10px] text-[#ea580c] font-bold">
                            {language === 'si' ? 'වත්මන් තත්ත්වය' : 'CURRENT'}
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-slate-500 font-sans">{s.date}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
