export interface Product {
  id: string;
  name: string;
  nameSi?: string;
  category: string;
  categorySi?: string;
  price: number;
  originalPrice?: number;
  discountPercent?: number;
  rating: number;
  reviewsCount: number;
  imageUrl: string;
  imageAlt: string;
  badge?: string;
  badgeSi?: string;
  stock?: number;
  sold?: number;
  description: string;
  descriptionSi?: string;
  vendor: string;
  vendorSi?: string;
  isDailyDeal?: boolean;
  colors?: string[];
  colorsSi?: string[];
  specs?: { [key: string]: string };
  specsSi?: { [key: string]: string };
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedColor?: string;
}

export interface CategoryItem {
  id: string;
  name: string;
  nameSi?: string;
  iconName: string;
  itemCount: number;
  subcategories: string[];
  subcategoriesSi?: string[];
}

export type Currency = 'USD' | 'EUR' | 'GBP';
export type Language = 'en' | 'si';

